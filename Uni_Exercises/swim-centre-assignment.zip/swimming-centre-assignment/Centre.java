
/**
import java.util.*;
/**
 * An amateur swimming club.
 * 
 * @author Mick Wood 
 * @version November 2004
 */
public class Centre
{
    private String name;
    
    public Centre(String name)
    {
        this.name = name;
    }          
}
